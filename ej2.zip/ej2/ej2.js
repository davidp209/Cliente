﻿// UT2 cookies

window.onload = function() { 


var canvas;

var ctx, x, y;
var primero, segundo;

	function generaDatos() {

		primero = false;
		
		// Generamos las coordenadas iniciales
		x = Math.random()*600;
		y = 0;
	}

	function generaAnimación() {
		
		// aproximadamente a 24 frames por segundo (fps)
		// Limpiamos el canvas, eliminando el contenido
		// desde el punto (0, 0) al punto (600, 400)
		ctx.clearRect(0, 0, 600, 400);

		// Generamos nuevas coordenadas
		// Que basicamente representan un desplazamiento lineal
		// Y dibujamos nuestra figura
		ctx.fillRect(x, y, 25, 25);

		if (y>=375) {
		   
		   primero = true;
		}
		else y=y+1;


		if (primero) {

		   clearInterval(id);

		}
	}

	// Obtenemos una referencia al canvas
	canvas = document.getElementById('miCanvas');

	// Y a su contexto 2d
	ctx = canvas.getContext('2d');

	generaDatos();
	
	var id = setInterval(generaAnimación, 1000/24);

	generaAnimación();




}


